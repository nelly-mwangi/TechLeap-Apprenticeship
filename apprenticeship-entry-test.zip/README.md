# Apprenticeship Entry Test

This repository contains my solutions for the Apprenticeship Entry Test covering:
1. Logic & Problem Solving  
2. Web / Software Development  
3. Debugging & Reasoning  
4. Version Control & Collaboration

Each section includes both code and explanations.
